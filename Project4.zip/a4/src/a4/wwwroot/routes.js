﻿(function () {
    'use strict';

    angular
        .module('app')
        .config(function ($stateProvider, $urlRouterProvider, $httpProvider) {

            $urlRouterProvider.otherwise("/");

            // $httpProvider.interceptors.push('myHttpInterceptor');
            //
            // Now set up the states

            $stateProvider
            .state('home', {
                url: "/",
                templateUrl: "home/home.html",
                controller: 'homeController'
            })
            .state('search', {
                url: "/search",
                templateUrl: "search/search.html",
                controller: 'searchController'
            })
            .state('update', {
                url: "/update/{value}",
                templateUrl: "update/update.html",
                controller: 'updateController',
                resolve: {
                    userService: 'userService',
                    login: function (userService, $stateParams) {
                        return userService.getInfo($stateParams.login);
                    }
                }
            }) .state('userState', {
                url: "/userState/{login}",
                templateUrl: "userState/userState.html",
                controller: 'userStateController',
                resolve: {

                    userService: 'userService',
                    login: function (userService, $stateParams) {
                        return userService.getInfo($stateParams.login);
                    }
                }
            })
            .state('add', {
                url: "/add",
                templateUrl: "add/add.html",
                controller: 'addController'
            })
           
        });
})();
