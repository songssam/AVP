﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('searchController', searchController);

    function searchController($scope, $state, $http, $q) {
        $scope.title = 'searchController';
        $scope.type = 1;
        $scope.search_box;
        $scope.deleteId;
        $scope.check;
        activate();

        $scope.data = {
            saveData: []
        }
        
        readResult().then(
          function (imageUrl) {
              $scope.data.saveData = imageUrl;
              for (var i = 0; i < $scope.data.saveData.length; i++) {
                  var localTime = moment($scope.data.saveData[i].dueDate).local().format('MM-DD-YYYY hh:mm A');
                  $scope.data.saveData[i].dueDate = localTime;
              }
              console.log(' DATA ' + $scope.data.saveData);
          });

        $scope.updateResult = function (login) {
            $state.go('userState', { login: login });
            console.log("login " + login);
        }

        $scope.updateSearch = function () {

            $scope.showTable = 0;
            readResult().then(
              function (imageUrl) {
                  $scope.data.saveData = imageUrl;
                  console.log(' DATA ' + $scope.data.saveData);
              });
                  console.log($scope.data.saveData + ' Noresult');
        }

        function readResult() {
            var deferred = $q.defer();
            $http.get('http://localhost:35000/api/project').then(

            function handleSuccess(response) {
                console.log('Hurray!');
                console.log('http://localhost:35000/api/project')
                deferred.resolve(response.data);
            });
            return deferred.promise;
        }

        $scope.addResult = function () {
            addResult().then();
        }
        $scope.deleteResult = function (realID) {
            $scope.dealID = realID;
            getResult().then(
              function () {
                  console.log(' DATA ' + $scope.data.saveData);
                  console.log(' here ' + $scope.dealID)
              });

            console.log($scope.data.saveData + ' Noresult');
        }
       
        function getResult() {
            var deferred = $q.defer();
            $http.delete('http://localhost:35000/api/project/' + $scope.dealID).then(

            function handleSuccess(response) {
                console.log('Hurray!');
                console.log('http://localhost:35000/api/project' + $scope.dealID)
                deferred.resolve(response.data);
            });
            return deferred.promise;
        }

        function activate() { }
    }
})();
