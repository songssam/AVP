﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('addController', addController)

    function addController($scope, $http) {
        $scope.title = 'addController';
        $scope.type = 'Active';
        
        $scope.createTodo = function () {
            
            console.log(' 1234 ' + $scope.add_year + $scope.add_month);
            console.log($scope.add_month);
            addData();
        }
        
        function addData() {

            var item = {
                "tags": $scope.add_tags,
                "description": $scope.add_desc,
                "dueDate": $scope.add_year+'-'+$scope.add_month+'-'+$scope.add_day+'T'+$scope.add_hour+':'+$scope.add_minute+':00',
                "state": $scope.type
            }



            $http.post('http://localhost:35000/api/project', item);

        }
    }
})();
