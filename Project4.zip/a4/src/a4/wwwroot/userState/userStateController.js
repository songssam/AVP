﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('userStateController', function getuserStateController(login, $state, $scope, $q, $http) {
            $scope.login = login;
            $scope.type = "Active";

            $scope.change = function () {
                updateData();
                console.log('Hello');
            }
            function updateData() {
                console.log('here' + $scope.login.login)
                var item = {
                    "id": $scope.login.login,
                    "tags": $scope.add_tags,
                    "description": $scope.add_desc,
                    "dueDate": $scope.add_year + '-' + $scope.add_month + '-' + $scope.add_day + 'T' + $scope.add_hour + ':' + $scope.add_minute + ':00',
                    "state": $scope.type
                }
                console.log('I am called')
                    $http.put('http://localhost:35000/api/project', item);
            }
        }
     )
})();