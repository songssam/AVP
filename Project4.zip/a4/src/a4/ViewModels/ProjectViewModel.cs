﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace a4.ViewModels
{
    public class ProjectViewModel
    {
        public string Name { get; set; }
        public string Description { get; set; }
    }
}
