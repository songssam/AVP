﻿using a4.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace a4.Repositories
{
    class AlarmRepository : IAlarmRepository
    {
        private ProjectContext _context;

        public AlarmRepository(ProjectContext context)
        {
            _context = context;
        }

        public void Update(Alarm alarm)
        {
            var projectToUpdate = FindById(alarm.Id);
            projectToUpdate.time = alarm.time;
            _context.SaveChanges();
        }

        public IEnumerable<Alarm> List()
        {
            var projects = _context.Alarm.ToList();
            return projects;
        }

        public Alarm FindById(int id)
        {
            var project = _context.Alarm.First(p => p.Id == id);
            return project;
        }

     
    }
}
